<footer class="footer">
   &copy; copyright @ <?= date('Y'); ?> by <span>Varshil Raycha</span> | all rights reserved!
</footer>